<!DOCTYPE>

<html>
	<head>
<title> User Define Functions</title>
	</head>
	<body>
<?php
function Welcome(){
	echo "Welcome to PHP course <br>";
}

function Addition_Using_Function_Parameter($x,$y){
	$Result=$x+$y;
echo "Addition Using Function Parameter is: {$Result} <br>";
}

?>

	</body>
</html>
