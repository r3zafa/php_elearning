<!DOCTYPE>
<html>
	<head>
		<title>Variable</title>
	</head>
	<body>


 <?php 
$name="jazeb";
echo $name; echo " <br>";
$age=22;
echo $age; echo " <br>";
$a=3;
$b=6;
$c=$a+$b;
echo $c;

 ?>
	</body>
</html>