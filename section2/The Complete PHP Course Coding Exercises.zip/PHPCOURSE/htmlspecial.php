<!DOCTYPE>

<html>
	<head>
		<title>HTML SPecial Characters</title>
	</head>
	<body>
<?php
echo htmlspecialchars("Ali< is > me & i am < alex ? �� � � � � ");

?>
	    
	</body>
</html>
