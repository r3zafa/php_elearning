<?php
$Connection=mysql_connect('localhost','root','');
$ConnectingDB=mysql_select_db('phpcms',$Connection);
?>