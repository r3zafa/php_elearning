<?php
session_start();
?>
<?php
$_SESSION["Name"]="Jazeb Akram";
$Name=$_SESSION["Name"];
echo $Name;
?>
<br>
<?php
$_SESSION["Age"]="24";
$Age=$_SESSION["Age"];
echo $Age;
?>
<!DOCTYPE>

<html>
	<head>
		<title>Session</title>
	</head>
	<body>
<?php ?>
	    
	</body>
</html>
