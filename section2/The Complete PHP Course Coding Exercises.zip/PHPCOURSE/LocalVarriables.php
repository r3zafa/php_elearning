<!DOCTYPE>

<html>
	<head>
<title> Local Variables</title>
	</head>
	<body>
<?php

$MyNumber=456456;
function Addition(){
	
	$a=5;
	$b=2;
	$c=$a+$b;
	echo $MyNumber."<br>";
	echo "Addition is {$c}<br>";	
}

Addition();
?>

	</body>
</html>
