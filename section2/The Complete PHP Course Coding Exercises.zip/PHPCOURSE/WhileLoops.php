<!DOCTYPE>

<html>
	<head>
		<title>While Loops</title>
	</head>
	<body>
<?php ?>
		
		<?php
	$P=1;
	while($P<=15){
		echo "Jazebakram.com <br>";
		$P++;
	}
		
		?>
	</body>
</html>
