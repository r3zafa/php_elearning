<!DOCTYPE>

<html>
	<head>
		<title>HTML FORM FILE</title>
	</head>
	<body>
<?php ?>
    <fieldset>
    <legend>HTML 5 Form</legend>
    <form action="PHPFile.php" method="POST" >
<label for="Username">Username:</label>
<input id="Username" type="text" name="Username"><br><br>
<label for="Password">Password:</label>
&nbsp;<input id="Password" type="Password" name="Password"><br><br><br>
<input type="Submit" name="Submit" value="Submitted">
    </form>
    </fieldset>
	</body>
</html>
