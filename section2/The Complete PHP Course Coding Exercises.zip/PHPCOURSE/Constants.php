<!DOCTYPE>

<html>
	<head>
		<title>Constants</title>
	</head>
	<body>
<?php ?>
<?php
$Name=45;
define("Value_of_Pi",3.14);
define("Value_of_Gravity",9.8);
echo "PI VALUE: " . Value_of_Pi;
echo "G VALUE: " . Value_of_Gravity;

?><hr>
<?php

//Value_of_Pi=25+999+15+68;
//echo Value_of_Pi;
define("Value_of_Pi",1000);
echo "PI VALUE: " . Value_of_Pi;

?>

	</body>
</html>
